# Kirjoita for-toistolause, joka kirjoittaa joka toisen numeron yhdestä yhdeksään. (1,3,5,7,9)

for i in range(1,10,2):
    print(i)