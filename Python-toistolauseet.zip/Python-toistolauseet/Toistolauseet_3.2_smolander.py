# Kirjoita toistolause, joka toistaa 10 kierrosta.
# Lisää tyhjään listaan jokaista kierrosta vastaava numero. Lopuksi tulosta koko lista.

lista = []

for i in range(10):
    lista.append(i)

print(lista)