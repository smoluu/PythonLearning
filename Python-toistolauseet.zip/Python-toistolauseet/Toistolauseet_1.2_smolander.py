# Kirjoita for-toistolause, joka kirjoittaa numerot kymmenestä kahteenkymmeneen.

for i in range(10,21):
    print(i)