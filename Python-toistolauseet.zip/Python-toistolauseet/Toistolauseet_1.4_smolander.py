# Kirjoita for-toistolause, joka kirjoittaa viiden kertotaulun luvut kymmenen toistoon asti
# (5,10,15......90,95,100)

for i in range(5,101,5):
    print(i)