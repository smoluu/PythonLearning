# Kirjoita toistolause, joka kirjoittaa listassa olevien hedelmien nimiä yksi kerrallaan.
# Kirjoita listaan ainakin viisi hedelmää.

hedelmät = ["mansikka","mustikka","persikka","päärynä","omena"]

for i in range(len(hedelmät)):
    print(hedelmät[i])