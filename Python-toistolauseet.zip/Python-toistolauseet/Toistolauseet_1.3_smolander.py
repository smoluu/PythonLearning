#  Kirjoita for-toistolause, joka kirjoittaa numerot sadasta nollaan. (100, 99, 98, jne.)

for i in range(101):
    print(abs(i-100))