# Kirjoita for-toistolause, joka kirjoittaa luvut nollasta kahteenkymmeneen.

for i in range(21):
    print(i)