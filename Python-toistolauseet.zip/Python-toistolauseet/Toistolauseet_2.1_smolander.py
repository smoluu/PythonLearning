# Kirjoita while-toistolause, joka tulostaa luvut nollasta kahteenkymmeneen

luku = 0
while luku <= 20:
    print(luku)
    luku += 1